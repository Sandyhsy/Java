public class A1093325_Project1_Environment
{
    private double defaultDecisionProbability;      //宣告一私有的雙精密度浮點數變數

    public A1093325_Project1_Environment()          //建構子
    {
    }

    public void setDefaultDecisionProbability(double defaultDecisionProbability)    //設定預設機率
    {
        if (defaultDecisionProbability < 0 || defaultDecisionProbability > 1)       //機率小於0或大於1
            throw new IllegalArgumentException("default probability is less than 0 or more than 1"); //將例外丟出
        
        //將傳入的defaultDecisionProbability定義為此class的預設機率
        this.defaultDecisionProbability = defaultDecisionProbability;       
    }

    public double getDefaultDecisionProbability()   //取機率值
    {
        return this.defaultDecisionProbability;     //回傳機率值
    }
}

