public class A1093325_Project1_Main
{
    public static void main(String[] args)
    {
        A1093325_Project1_Game game = new A1093325_Project1_Game();     //建立一A1093325_Project1_Game的物件
        game.runGame();                                                 //呼叫game物件中的runGame()
    }
}