import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class A1093325_Project1_Game
{
    private static final Random RANDOM = new Random(System.currentTimeMillis());    //定義RANDOM為以毫秒返回當前時間
    private static final int ROUND = 5;                                             //定義ROUND(回合)為五回合
    private final ArrayList<A1093325_Project1_Agent> explorers =  new ArrayList<>();//定義explorers(玩家)為A1093325_Project1_Agent型態的陣列
    private final ArrayList<A1093325_Project1_Gemstone> deck = new ArrayList<>();   //定義deck(卡牌堆)為A1093325_Project1_Gemstone型態的陣列
    private final ArrayList<A1093325_Project1_Gemstone> path = new ArrayList<>();   //定義path(通道)為A1093325_Project1_Gemstone型態的陣列

    public A1093325_Project1_Game()     //建構子(定義玩家編號)
    {
        this.explorers.add(new A1093325_Project1_Agent(0));     
        this.explorers.add(new A1093325_Project1_Agent(1));     
        this.explorers.add(new A1093325_Project1_Agent(2));     
        this.explorers.add(new A1093325_Project1_Agent(3));     
        this.explorers.add(new A1093325_Project1_Agent(4));     
        this.explorers.add(new A1093325_Project1_Agent(5));     
        
        this.setUpCards();      //定義setUpCards()之預設值
    }
                                
    public void runGame()       //遊戲規則執行
    {
        for (int round = 0; round < ROUND; round++)     //遊戲五回合的迴圈
        {
            System.out.printf("ROUND %d START!%n%n", round+1);      //印出當前回合數
            path.clear();      //清除通道中的資料
            setUpCards();      //重新設定卡牌堆中的卡牌
            shuffleDeck();     //洗牌
            for(int number=0;number<explorers.size();number++){             //六位玩家的迴圈
                explorers.get(number).setInExploring(true);    //初始化每位玩家狀態(設定為true)
            }

            while (this.isAnyoneStay() && this.path.size() < 10)        //當至少有一位玩家留下和通道的大小小於10時持續做迴圈
            {                   
                A1093325_Project1_Gemstone Gemstone = deck.get(0);    //定義Gemstone為卡牌堆中最上方的牌(即抽牌)
                path.add(Gemstone);                                         //將抽到的牌加進通道中
                Gemstone.share(getStayExplorers());                         //分寶石給所有繼續探險的玩家
                System.out.println(path);                                   //印出通道資訊
                deck.remove(0);                                       //將抽到的卡牌從卡牌堆中移除
                for(int num=0;num<explorers.size();num++){                  //玩家的迴圈
                    if(explorers.get(num).isInExploring()){                  //如果玩家繼續探險
                        System.out.printf("%s has %d gem(s).%n", explorers.get(num), explorers.get(num).getCollectedGems());
                                                                            //印出玩家編號及至此回合為止所收集到的寶石數
                    }
                    else{                                                   //玩家選擇離開
                        System.out.printf("%s left.%n", explorers.get(num));
                                                                            //印出要離開的玩家編號
                        }
                }
                System.out.println("----- STAY or LEAVE -----");         //印出詢問玩家要離開與否
                A1093325_Project1_Environment environment = this.createEnvironment();   //建立A1093325_Project1_Environment物件
                ArrayList<A1093325_Project1_Agent> before =  new ArrayList<>(); //建立before為A1093325_Project1_Agent型態的陣列
                ArrayList<A1093325_Project1_Agent> after =  new ArrayList<>();  //建立after為A1093325_Project1_Agent型態的陣列
                ArrayList<A1093325_Project1_Agent> leave =  new ArrayList<>();  //建立leave為A1093325_Project1_Agent型態的陣列
                before = getStayExplorers();                    //將目前繼續探險的玩家放入before陣列中
                int countexp = getStayExplorers().size();       //用countexp存繼續探險玩家的數量
                for(int j=0;j<getStayExplorers().size();j++){   //目前繼續探險玩家數的迴圈
                    getStayExplorers().get(j).act(environment); //目前繼續探險的玩家做是繼續探險的判定
                }
                after = getStayExplorers();                     //將判斷後仍繼續探險的玩家放入after陣列中
                if(countexp == getStayExplorers().size()){      //如果判定前後的玩家數量相同
                    System.out.printf("Everyone keeps exploring.%n%n"); //印出所有玩家接繼續探險
                }else{                                          //若判定前後的玩家數量不同
                    for(A1093325_Project1_Agent E:before){      //取出判定前的玩家依序進行迴圈
                        if(after.contains(E)==false){           //若判定後的玩家不存在於判定前的探險者列中 則代表他想離開
                            System.out.printf("%s wants to leave.%n", E);   //印出判定後要離開的玩家
                            leave.add(E);                       //把離開玩家加進leave陣列中
                        }
                    }    
                    for(int k=0;k<path.size();k++){         //依通道長度進行迴圈
                        path.get(k).share(leave);           //離開玩家分寶石(每個通道中所剩下的寶石都須平分給所有離開玩家)
                    }
                    System.out.println(); 
                }
            }   //while結束
            for(int p=0;p<explorers.size();p++){        //依玩家數量進行迴圈
                explorers.get(p).storeGemsIntoTent();   //將玩家的寶石都存到帳篷內
            }
            System.out.printf("ROUND %d END!%n%n",round+1); //印出第幾回合結束
        }   //五回合for
        System.out.println("GAME OVER!");                    //印出遊戲結束
        System.out.println();
        System.out.println("----- Final result -----");      //印出遊戲結束的總結果分隔線

        for (A1093325_Project1_Agent explorer : this.explorers){    
            System.out.println(explorer + ": " + explorer.getGemsInsideTent());     //印出每位玩家在遊戲中獲得的所有寶石數
        }
    }


    private void setUpCards()   //設定卡牌
    {
        this.deck.add(new A1093325_Project1_Gemstone(1));
        this.deck.add(new A1093325_Project1_Gemstone(2));
        this.deck.add(new A1093325_Project1_Gemstone(3));
        this.deck.add(new A1093325_Project1_Gemstone(4));
        this.deck.add(new A1093325_Project1_Gemstone(5));
        this.deck.add(new A1093325_Project1_Gemstone(5));
        this.deck.add(new A1093325_Project1_Gemstone(7));
        this.deck.add(new A1093325_Project1_Gemstone(7));
        this.deck.add(new A1093325_Project1_Gemstone(9));
        this.deck.add(new A1093325_Project1_Gemstone(11));
        this.deck.add(new A1093325_Project1_Gemstone(11));
        this.deck.add(new A1093325_Project1_Gemstone(13));
        this.deck.add(new A1093325_Project1_Gemstone(14));
        this.deck.add(new A1093325_Project1_Gemstone(15));
        this.deck.add(new A1093325_Project1_Gemstone(17));
    }

    private void shuffleDeck()      //洗牌
    {
        Collections.shuffle(this.deck, RANDOM);
    }

    private ArrayList<A1093325_Project1_Agent> getStayExplorers()   //取繼續探索的玩家並存成陣列
    {
        ArrayList<A1093325_Project1_Agent> arrlist = new ArrayList<>();     //建立一新陣列arrlist
        for(int i=0;i<explorers.size();i++){                 //依玩家數量進行迴圈
            if(explorers.get(i).isInExploring()==true){      //若玩家繼續探險
                arrlist.add(explorers.get(i));               //把玩家編號存進arrlist中
            }
        }
        return arrlist;     //回傳陣列
    }

    private boolean isAnyoneStay()  //是否還有玩家繼續探索的判斷
    {
        if(getStayExplorers().size()==0){ //若玩家數量等於0
            return false;                 //則回傳false
        }
        else{               //若玩家數量不等於0
            return true;    //則回傳true
        }
    }

    private A1093325_Project1_Environment createEnvironment()   //機率值設定
    {
        //建立A1093325_Project1_Environment新物件
        A1093325_Project1_Environment environment = new A1093325_Project1_Environment();
        //設定預設機率為0.65
        environment.setDefaultDecisionProbability(0.65);
        //回傳機率
        return environment;
    }

    private static void doNothing(long millisecond)
    {
        if (millisecond > 2000)
            throw new IllegalArgumentException("timeout value is over 2000");

        try
        {
            Thread.sleep(millisecond);
        }
        catch (InterruptedException e)
        {
            throw new IllegalStateException("unexpected interruption");
        }
    }
}
