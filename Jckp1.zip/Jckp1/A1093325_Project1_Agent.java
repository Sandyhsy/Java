public class A1093325_Project1_Agent
{
    private final int number;        // 玩家編號
    private boolean inExploring;     // 玩家繼續探險與否布林值   
    private int collectedGems;       // 玩家一回合獲得的寶石數
    private int gemsInsideTent;      // 帳篷內玩家的寶石數
    
    public A1093325_Project1_Agent(int number)      //建構子
    {
        this.number = number;           //將傳入的number定義為此class的玩家編號
        this.inExploring = false;       //探索與否的預設值為false(即回營地)
        this.collectedGems = 0;         //玩家獲得寶石數初始值為0
        this.gemsInsideTent = 0;        //帳篷內初始值為0  
    }

    public int getNumber()      //取玩家編號
    {
	    return number;          //回傳編號
    }

    public boolean isInExploring()      //玩家要繼續探索與否(ture為繼續探索，false為回營地)
    {
	    return inExploring;             //回傳true或false
    }

    public void setInExploring(boolean inExploring)     //設定玩家要繼續探索與否
    {
        this.inExploring = inExploring;                 //將傳入的boolean值定義為此class的inExploring
    }

    public int getCollectedGems()       //取玩家收集的寶石數
    {
	    return collectedGems;           //回傳收集寶石數
    }

    public int getGemsInsideTent()      //取帳篷內的寶石數
    {
	    return gemsInsideTent;          //回傳帳內寶石數
    }
    public void addCollectedGems(int additionalGems)                //添加玩家的寶石數
    {
        this.collectedGems = getCollectedGems() + additionalGems;   //將添加的寶石數與玩家原本的寶石數相加
    }

    public void storeGemsIntoTent()                                         //將玩家獲得的寶石收至帳篷中
    {
        this.gemsInsideTent = getGemsInsideTent() + getCollectedGems();     //將帳篷內原本的寶石數與獲得的寶石數相加
        this.collectedGems = 0;                                             //因為已回到營地中，所以把獲得的寶石歸零
    }
    
    @Override
    public String toString()
    {
        return "Explorer " + this.number;   //印出玩家編號
    }

    public void act(A1093325_Project1_Environment environment)      //玩家是否繼續探險的判定
    {
        if (this.inExploring)       //若繼續探險
        {
            double choice = Math.random();      //形成一隨機數放進choice中
            this.inExploring = (choice < environment.getDefaultDecisionProbability());      
            //定義玩家是否繼續探險，choice小於預設機率值則回傳true，反之則回傳false
        }
    }
}