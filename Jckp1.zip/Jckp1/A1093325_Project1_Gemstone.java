import java.util.ArrayList;

public class A1093325_Project1_Gemstone
{
    private final int value;    //卡牌上的寶石數
    private int remainValue;    //剩餘寶石數
    
    public A1093325_Project1_Gemstone(int value)     //建構子
    {
        this.value = value;             //將傳入的value定義為此class卡牌上的寶石數
        this.remainValue = value;       //將傳入的value定義為此class的剩餘寶石數
    }

    public int getValue()               //取卡牌上的寶石數
    {
        return this.value;              //回傳卡牌上的寶石數
    }

    public int getRemainValue()         //取剩餘的寶石數
    {
        return this.remainValue;        //回傳剩餘的寶石數
    }

    public void resetValue()            //重新定義卡牌上的寶石數
    {
        this.remainValue=this.value;    //將剩餘的寶石數定義為卡牌上的寶石數
    }

    public String name()                //定義字串函數
    {
        return "Gemstone";              //回傳字串
    }

    public void share(ArrayList<A1093325_Project1_Agent> receivers)   //平分寶石給玩家
    {
        int additionalGems = getRemainValue()/receivers.size();       //定義每人分到的寶石量為剩餘的寶石數除以所有人數
        for(int number=0;number<receivers.size();number++){           //依玩家數做迴圈
            receivers.get(number).addCollectedGems(additionalGems);   //玩家儲存寶石
        }
        this.remainValue = getRemainValue()%receivers.size();         //定義剩餘的寶石數為分剩的寶石數
    }

    @Override
    public String toString()
    {
        return String.format("<%d/%d>", this.remainValue, this.value);  //印出剩餘寶石數及卡牌上的寶石數
    }
}

