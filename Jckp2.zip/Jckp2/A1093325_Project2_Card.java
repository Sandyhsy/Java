public abstract class A1093325_Project2_Card
{
    private final int type;     //此卡牌的類型

    public A1093325_Project2_Card(int type)     //constructor
    {
        this.type = type;
    }

    public abstract String name();      //定義一name的抽象類別

    public int getType()    //取卡牌類型的method
    {
        return this.type;
    }
}
