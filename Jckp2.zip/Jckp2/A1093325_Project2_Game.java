import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class A1093325_Project2_Game
{
    private static final Random RANDOM = new Random(System.currentTimeMillis());    //定義RANDOM用來洗牌
    private static final int ROUND = 2;                                             //定義ROUND為五回合
    private final ArrayList<A1093325_Project2_Agent> explorers = new ArrayList<>(); //定義explorers(玩家)為A1093325_Project2_Agent型態的陣列
    private final ArrayList<A1093325_Project2_Card> deck = new ArrayList<>();//定義deck(卡牌堆)為A1093325_Project2_Card型態的陣列
    private final ArrayList<A1093325_Project2_Card> path = new ArrayList<>();//定義path(通道)為A1093325_Project2_Card型態的陣列
    private final ArrayList<A1093325_Project2_Artifact> artifacts = new ArrayList<>();  //各回合都會有一特定的文物存入
    private final ArrayList<A1093325_Project2_Hazard> occurredHazards = new ArrayList<>();//在遊戲中發生的災難

    public A1093325_Project2_Game() //constructor
    {
        this.explorers.add(new A1093325_Project2_Agent(1));
        this.explorers.add(new A1093325_Project2_Agent(2));
        this.explorers.add(new A1093325_Project2_Agent(3));
        this.explorers.add(new A1093325_Project2_Agent(4));
        this.explorers.add(new A1093325_Project2_Agent(5));
        
        this.setUpCards();
    }
    
    public void runGame()
    {
        for (int round = 0; round < ROUND; round++)
        {
            System.out.printf("ROUND %d START!%n%n", round+1);      //印出當前回合數
            for(int number=0;number<explorers.size();number++){             //六位玩家的迴圈
                explorers.get(number).setInExploring(true);    //初始化每位玩家狀態(設定為true)
            }
            path.clear();   //清除通道中的資料
            if(round>1){
                deck.remove(artifacts.get(round-1));  //remove前一回合的文物
            }
            deck.add(artifacts.get(round));     //將此回合的文物放入
            for(int i=0;i<path.size();i++){
                if(path.get(i).name()=="Gemstone"){
                    ((A1093325_Project2_Gemstone) path.get(i)).resetValue();    //重新設定所有寶石卡牌resetValue();
                }
            }
            for(int i=0;i<path.size();i++){     //將通道上的卡牌洗回牌庫
                deck.add(path.get(i));
            }
            shuffleDeck();      //洗牌
            int count = 0;      //定義一值count做抽牌用

            while (this.isAnyoneStay())
            {
                path.add(deck.get(count));     //依序抽牌並加進通道中
                count++;    //count加1(即抽取下一張牌)
                if(path.get(path.size()-1).name()=="Gemstone"){     //若抽到寶石牌
                    //分寶石給所有繼續探險的玩家
                    ((A1093325_Project2_Gemstone)path.get(path.size()-1)).share(getStayExplorers());
                }
                System.out.println(path);       //印出通道資訊
                boolean isOcurredHazards = false;   //設定一boolean值isOcurredHazards判斷是否發生災難
                if(path.get(path.size()-1).name()=="Spikes" || path.get(path.size()-1).name()=="Spiders" || 
                    path.get(path.size()-1).name()=="Mummy" || path.get(path.size()-1).name()=="Curse" ||  
                    path.get(path.size()-1).name()=="Collapse"){    //當通道中出現災難牌的名字時
                    for(int i = 0; i < this.path.size()-1; i++){  
                        //當通道中的卡牌名與occurredHazards中卡牌名相同時(即出現兩次相同災難)
                        if(path.get(path.size()-1).name().equals(path.get(i).name())){  
                            isOcurredHazards = true;    //將boolean值設為true
                            for(int j=0;j<explorers.size();j++){
                                explorers.get(j).flee();   //災難發生所有探險中的玩家逃跑
                            }
                            break;
                        }
                    }
                    //將災難牌加進occurredHazards陣列中
                    occurredHazards.add((A1093325_Project2_Hazard)path.get(path.size()-1));
                    deck.remove(this.deck.size()-1);     //將抽到的災難卡(同時也是抽到卡牌的最後一張)刪除    
                }
                for(int num=0;num<explorers.size();num++){      //玩家的迴圈
                    if(explorers.get(num).isInExploring()){     //如果玩家繼續探險
                        System.out.printf("%s has %d gem(s).%n", explorers.get(num), explorers.get(num).getCollectedGems());
                        //印出玩家編號及至此回合為止所收集到的寶石數
                    }
                    else{   //如果玩家選擇離開
                        System.out.printf("%s left.%n", explorers.get(num));
                        //印出要離開的玩家編號
                    }
                }

                System.out.println("----- STAY or LEAVE -----");
                if(isOcurredHazards){       //若災難發生
                    //印出災難名
                    System.out.printf("%s hazard occurs, all explorers attempt to flee!%n%n", this.occurredHazards.get(this.occurredHazards.size()-1).name());
                }
                else{
                    A1093325_Project2_Environment environment = this.createEnvironment();

                    ArrayList<A1093325_Project2_Agent> before =  new ArrayList<>(); //建立before為A1093325_Project1_Agent型態的陣列
                    ArrayList<A1093325_Project2_Agent> after =  new ArrayList<>();  //建立after為A1093325_Project1_Agent型態的陣列
                    ArrayList<A1093325_Project2_Agent> leave =  new ArrayList<>();  //建立leave為A1093325_Project1_Agent型態的陣列
                    before = getStayExplorers();                    //將目前繼續探險的玩家放入before陣列中
                    int countexp = getStayExplorers().size();       //用countexp存繼續探險玩家的數量
                    for(int j=0;j<getStayExplorers().size();j++){   //目前繼續探險玩家數的迴圈
                        getStayExplorers().get(j).act(environment); //目前繼續探險的玩家做是繼續探險的判定
                    }
                    after = getStayExplorers();                     //將判斷後仍繼續探險的玩家放入after陣列中
                    if(countexp == getStayExplorers().size()){      //如果判定前後的玩家數量相同
                        System.out.printf("Everyone keeps exploring.%n%n"); //印出所有玩家接繼續探險
                    }else{                                          //若判定前後的玩家數量不同
                        for(A1093325_Project2_Agent E:before){      //取出判定前的玩家依序進行迴圈
                            if(after.contains(E)==false){           //若判定後的玩家不存在於判定前的探險者列中 則代表他想離開
                                System.out.printf("%s wants to leave.%n", E);   //印出判定後要離開的玩家
                                leave.add(E);                       //把離開玩家加進leave陣列中
                            }
                        }    
                        for(int k=0;k<path.size();k++){         //依通道長度進行迴圈
                            if(path.get(k).name()=="Gemstone"){
                                //離開玩家分寶石(每個通道中所剩下的寶石都須平分給所有離開玩家)
                                ((A1093325_Project2_Gemstone)path.get(k)).share(leave);
                            }    
                        }
                        
                        if(path.get(path.size()-1).name()=="Meteoric Dagger" || path.get(path.size()-1).name()=="Ankh" || 
                        path.get(path.size()-1).name()=="Falcon Pectoral" || path.get(path.size()-1).name()=="Crook and Flail" || 
                        path.get(path.size()-1).name()=="Mask of Tutankhamun"){     //當卡牌名稱為神器牌時
                            ((A1093325_Project2_Artifact)path.get(path.size()-1)).share(leave);     //做神器牌分配
                        }
                        System.out.println(); 
                    }
                }
            }//(while的)若還有人留下

            for(int p=0;p<explorers.size();p++){        //依玩家數量進行迴圈
                explorers.get(p).storeGemsIntoTent();   //將玩家的寶石都存到帳篷內
            }

            System.out.printf("ROUND %d END!%n%n",round+1); //印出第幾回合結束

        }//(for的)五回合

        System.out.println("GAME OVER!");
        System.out.println();
        System.out.println("----- Final result -----");

        for (A1093325_Project2_Agent explorer : this.explorers)
            System.out.println(explorer + ": " + explorer.totalValue());    //印出玩家最終分數

        System.out.println();
        System.out.println("Winner: " + this.getWinners());     //印出最終贏家(們)
    }//(game的)

    private void setUpCards()
    {
        this.deck.add(new A1093325_Project2_Hazard(0));
        this.deck.add(new A1093325_Project2_Hazard(0));
        this.deck.add(new A1093325_Project2_Hazard(0));
        this.deck.add(new A1093325_Project2_Hazard(1));
        this.deck.add(new A1093325_Project2_Hazard(1));
        this.deck.add(new A1093325_Project2_Hazard(1));
        this.deck.add(new A1093325_Project2_Hazard(2));
        this.deck.add(new A1093325_Project2_Hazard(2));
        this.deck.add(new A1093325_Project2_Hazard(2));
        this.deck.add(new A1093325_Project2_Hazard(3));
        this.deck.add(new A1093325_Project2_Hazard(3));
        this.deck.add(new A1093325_Project2_Hazard(3));
        this.deck.add(new A1093325_Project2_Hazard(4));
        this.deck.add(new A1093325_Project2_Hazard(4));
        this.deck.add(new A1093325_Project2_Hazard(4));
        
        this.deck.add(new A1093325_Project2_Gemstone(0, 1));
        this.deck.add(new A1093325_Project2_Gemstone(1, 2));
        this.deck.add(new A1093325_Project2_Gemstone(2, 3));
        this.deck.add(new A1093325_Project2_Gemstone(3, 4));
        this.deck.add(new A1093325_Project2_Gemstone(4, 5));
        this.deck.add(new A1093325_Project2_Gemstone(4, 5));
        this.deck.add(new A1093325_Project2_Gemstone(5, 7));
        this.deck.add(new A1093325_Project2_Gemstone(5, 7));
        this.deck.add(new A1093325_Project2_Gemstone(6, 9));
        this.deck.add(new A1093325_Project2_Gemstone(7, 11));
        this.deck.add(new A1093325_Project2_Gemstone(7, 11));
        this.deck.add(new A1093325_Project2_Gemstone(8, 13));
        this.deck.add(new A1093325_Project2_Gemstone(9, 14));
        this.deck.add(new A1093325_Project2_Gemstone(10, 15));
        this.deck.add(new A1093325_Project2_Gemstone(11, 17));
        
        this.artifacts.add(new A1093325_Project2_Artifact(0, 5));
        this.artifacts.add(new A1093325_Project2_Artifact(1, 7));
        this.artifacts.add(new A1093325_Project2_Artifact(2, 8));
        this.artifacts.add(new A1093325_Project2_Artifact(3, 10));
        this.artifacts.add(new A1093325_Project2_Artifact(4, 12));
    }

    private void shuffleDeck()  //洗牌
    {
        Collections.shuffle(this.deck, RANDOM);
    }

    private ArrayList<A1093325_Project2_Agent> getStayExplorers()   //取繼續探索的玩家並存成陣列
    {
        ArrayList<A1093325_Project2_Agent> arrlist = new ArrayList<>();     //建立一新陣列arrlist
        for(int i=0;i<explorers.size();i++){                 //依玩家數量進行迴圈
            if(explorers.get(i).isInExploring()==true){      //若玩家繼續探險
                arrlist.add(explorers.get(i));               //把玩家編號存進arrlist中
            }
        }
        return arrlist;     //回傳陣列
    }

    private boolean isAnyoneStay()  //是否還有玩家繼續探索的判斷
    {
        if(getStayExplorers().size()==0){ //若玩家數量等於0
            return false;                 //則回傳false
        }
        else{               //若玩家數量不等於0
            return true;    //則回傳true
        }
    }

    private ArrayList<A1093325_Project2_Agent> getWinners()
    {     
        ArrayList<A1093325_Project2_Agent> winner = new ArrayList<A1093325_Project2_Agent>();   //建立一新物件
        int highestScore = 0;
        for(int i = 0; i < explorers.size(); i++){    //跑玩家人數
            if(this.explorers.get(i).totalValue() > highestScore){    //找大於highestScore的分數
                highestScore = this.explorers.get(i).totalValue();    //將highestScore替換成比highestScore大的分數
            }
        }  
        for(int j = 0; j < explorers.size(); j++){    //跑玩家人數
            if(this.explorers.get(j).totalValue() == highestScore){   //如果玩家的分數與最高分一樣
                winner.add(this.explorers.get(j));    //加入winner陣列
            }
        }  
        return winner;  //回傳分數最高者
    }

    private A1093325_Project2_Environment createEnvironment()
    {
        A1093325_Project2_Environment environment = new A1093325_Project2_Environment();

        environment.setDefaultDecisionProbability(0.65);

        return environment;
    }

    private static void doNothing(long millisecond)
    {
        if (millisecond > 2000)
            throw new IllegalArgumentException("timeout value is over 2000");

        try
        {
            Thread.sleep(millisecond);
        }
        catch (InterruptedException e)
        {
            throw new IllegalStateException("unexpected interruption");
        }
    }
}
