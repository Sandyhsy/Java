import java.util.ArrayList;

public abstract class A1093325_Project2_Treasure extends A1093325_Project2_Card
{
    private final int value;    //宣告一變數value為數字型態(為價值)
    
    public A1093325_Project2_Treasure(int type, int value)      //constructor
    {
        super(type);            //指向A1093325_Project2_Card的type
        this.value = value;
    }

    public int getValue()       //取value值
    {
        return this.value;      //回傳寶物卡牌的value
    }

    public abstract void share(ArrayList<A1093325_Project2_Agent> receivers);       //定義一抽象函數share()
}
