public class A1093325_Project2_Main     //主程式
{
    public static void main(String[] args)
    {
        A1093325_Project2_Game game = new A1093325_Project2_Game();     //建立一A1093325_Project2_Game的物件叫game
        game.runGame();                                                 //呼叫game的函數
    }
}
