import java.util.ArrayList;

public class A1093325_Project2_Gemstone extends A1093325_Project2_Treasure
{
    private int remainValue;
    
    public A1093325_Project2_Gemstone(int type, int value)
    {
        super(type, value);
        this.remainValue = value;
    }

    public int getRemainValue()
    {
        return this.remainValue;              //回傳卡牌上的寶石數
    }
    
    public void resetValue()
    {
        this.remainValue=getValue();    //將剩餘的寶石數定義為卡牌上的寶石數
    }

    @Override
    public String name()
    {
        return "Gemstone";
    }

    @Override
    public void share(ArrayList<A1093325_Project2_Agent> receivers)   //平分寶石給玩家
    {   
        int additionalGems = getRemainValue()/receivers.size();       //定義每人分到的寶石量為剩餘的寶石數除以所有人數
        for(int number=0;number<receivers.size();number++){           //依玩家數做迴圈
            receivers.get(number).addCollectedGems(additionalGems);   //玩家儲存寶石
        }
        this.remainValue = getRemainValue()%receivers.size();         //定義剩餘的寶石數為分剩的寶石數
    }
    
    @Override
    public String toString()
    {
        return String.format("<G: %d/%d>", this.remainValue, this.getValue());
    }
}
