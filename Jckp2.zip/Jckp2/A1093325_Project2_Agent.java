import java.util.ArrayList;

public class A1093325_Project2_Agent
{
    private final int number;       //玩家編號
    private boolean inExploring;	//玩家留與不留狀態
    private int collectedGems;	    //該回合獲得的寶石數
    private int gemsInsideTent;	    //收在帳棚內的寶石數

    private final ArrayList<A1093325_Project2_Artifact> ownedArtifacts = new ArrayList<>();   //玩家擁有的文物
    
    public A1093325_Project2_Agent(int number)	//constructor
    {
        this.number = number;
        this.inExploring = false;
        this.collectedGems = 0;
        this.gemsInsideTent = 0;
    }

    public int getNumber()
    {
        return this.number;
    }

    public boolean isInExploring()
    {
        return this.inExploring;
    }

    public void setInExploring(boolean inExploring)
    {
        this.inExploring = inExploring;
    }

    public int getCollectedGems()
    {
        return this.collectedGems;
    }

    public int getGemsInsideTent()
    {
        return this.gemsInsideTent;
    }

    public void addCollectedGems(int additionalGems)
    {
        this.collectedGems = getCollectedGems() + additionalGems;
    }

    public void storeGemsIntoTent()
    {
        this.gemsInsideTent = getGemsInsideTent() + getCollectedGems();     //將帳篷內原本的寶石數與獲得的寶石數相加
        this.collectedGems = 0;   
    }

    public ArrayList<A1093325_Project2_Artifact> getOwnedArtifacts()
    {
        return this.ownedArtifacts;
    }

    public void flee()
    {
        this.collectedGems = 0;
        this.setInExploring(false);
    }

    public int totalValue()     //總分計算
    {
        int total = 0;              //設定一變數total裝最後的分數
        int artifactTotal = 0;  //設定一變數裝所有文物加總的分數
        for(int i=0;i<getOwnedArtifacts().size();i++){      //跑總共所獲得的文物數量
            //依序將文物價值加入artifactTotal
            artifactTotal = artifactTotal + getOwnedArtifacts().get(i).getValue();  
        }
        total = getGemsInsideTent() + artifactTotal;    //總分為在帳篷內所有寶石的分數加上文物的分數
        return total;   //回傳總分
    }
    
    @Override
    public String toString()
    {
        return "Explorer " + this.number;
    }

    public void act(A1093325_Project2_Environment environment)
    {
        if (this.inExploring)
        {
            double choice = Math.random();
            this.inExploring = (choice < environment.getDefaultDecisionProbability());
        }
    }
}
