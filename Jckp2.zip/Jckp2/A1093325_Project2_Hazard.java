public class A1093325_Project2_Hazard extends A1093325_Project2_Card
{
    public A1093325_Project2_Hazard(int type)
    {
        super(type);    //使用父類別的type
    }
    @Override
    public String name()    //改寫name()函數
    {
        if(getType()==0){   //當type為0時
            return "Spikes";    //回傳Spikes
        }else if(getType()==1){
            return "Spiders";
        }else if(getType()==2){
            return "Mummy";
        }else if(getType()==3){
            return "Curse";
        }else if(getType()==4){
            return "Collapse";
        }else{      //當type不在0~4之間時
            return "Unknown";   //回傳Unknown
        }
    }
    @Override
    public String toString()    //改寫toString()函數
    {
        return String.format("<H: %s>", this.name());
    }
}
