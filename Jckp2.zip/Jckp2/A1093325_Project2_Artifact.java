import java.util.ArrayList;

public class A1093325_Project2_Artifact extends A1093325_Project2_Treasure
{
    private boolean inTomb;     //神器被拋在墓中與否
    
    public A1093325_Project2_Artifact(int type, int value)
    {
        super(type, value);     //從A1093325_Project2_Treasure中繼承
        this.inTomb = true;     //初執設為神器掉落在通道中
    }

    public boolean isInTomb()
    {
        return this.inTomb;
    }

    @Override
    public String name()
    {
        if(this.getType()==0){
            return "Meteoric Dagger";
        }else if(this.getType()==1){
            return "Ankh";
        }else if(this.getType()==2){
            return "Falcon Pectoral";
        }else if(this.getType()==3){
            return "Crook and Flail";
        }else if(this.getType()==4){
            return "Mask of Tutankhamun";
        }else{
            return "Unknown";
        }
    }
    
    @Override
    public void share(ArrayList<A1093325_Project2_Agent> receivers)
    {
        if(receivers.size()==1){    //當只有一人離開的時候
            //該玩家可以拿走當局的文物
            receivers.get(0).getOwnedArtifacts().add(new A1093325_Project2_Artifact(this.getType(),this.getValue()));
            this.inTomb = false;    //將狀態轉為false
        }
    }
    
    @Override
    public String toString()
    {
        if (this.inTomb)
            return String.format("<A: %s %d>", this.name(), this.getValue());
        else
            return "<A: --->";
    }
}
